package weaver.dfqcgsjszx.util.ecology.service_client;

import org.apache.activemq.ActiveMQMessageTransformation;
import org.apache.axis.encoding.Base64;
import weaver.dfqcgsjszx.util.ecology.service_client.doc.DocAttachment;
import weaver.dfqcgsjszx.util.ecology.service_client.doc.DocInfo;
import weaver.dfqcgsjszx.util.ecology.service_client.doc.DocServiceLocator;
import weaver.dfqcgsjszx.util.ecology.service_client.doc.DocServicePortType;


import javax.xml.rpc.ServiceException;

import java.io.ByteArrayOutputStream;
import java.io.File;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DocTest {
    public static void main(String[] args) throws RemoteException, MalformedURLException, ServiceException {
        //����service
        DocServicePortType service = new DocServiceLocator().getDocServiceHttpPort(new URL("http://121.40.45.20:9998/Gundam/services/DocService"));

        //��½
        String session = service.login("zdglxt", "zdgl@2021", 0, "127.0.0.1");

        //���������б�
        ArrayList<DocAttachment>  fileList = new ArrayList<>();


        //��丽������ѭ����䣬ע���������ΪPDF��OFFICE�ĵ���������䵽��һ��������
        File fileTemp = new File("/Users/hanjun/Downloads/����˵��.pdf");
        DocAttachment docAttachment = getDocAttachment(fileTemp);
        fileList.add(docAttachment);


        //�����ĵ�����
        DocInfo doc = getDocInfo("�����ļ�1213001",12001 ,1 , fileList);

        //�����ĵ�,����ֵΪOAϵͳ�е��ĵ�id
        int doc1 = service.createDoc(doc, session);


        System.out.println("����ֵ==="+doc1);
    }



    private static DocInfo getDocInfo(String docName, int docCreator, int secCategory, ArrayList<DocAttachment> fileList) {
        DocInfo doc = new DocInfo();
        doc.setId(0);
        doc.setDoccreatertype(1);
        doc.setAccessorycount(0);
        //���ĵ�id
        doc.setMaincategory(0);
        // ��Ŀ¼id
        doc.setSubcategory(0);
        // ��Ŀ¼id ��ϵOA����Ա��ȡ
        doc.setSeccategory(secCategory);
        doc.setDocStatus(1);
        doc.setDocType(2);

        //�ĵ�����ʱ�����
        doc.setDoccreatedate(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
        doc.setDoccreatetime(new SimpleDateFormat("HH:mm:ss").format(new Date()));
        doc.setDoclastmoddate(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
        doc.setDoclastmodtime(new SimpleDateFormat("HH:mm:ss").format(new Date()));

        //�ĵ�����
        doc.setDocSubject(docName);

        //�ĵ�HTML���� Ϊ��ʱĬ�ϴ򿪵�һ������
        doc.setDoccontent("");

        //�ĵ�������
        doc.setDoccreaterid(docCreator);

        //�ĵ�����
        DocAttachment[] da = null;
        if (fileList.size() > 0) {
            da = new DocAttachment[fileList.size()];
            fileList.toArray(da);
        }

        if (null != da && da.length > 0) {
            doc.setAttachments(da);
        }

        return doc;
    }


    private static DocAttachment getDocAttachment(File fileTemp) {
        DocAttachment docAttachment = new DocAttachment();
        byte[] content = null;
        try {
            int byteread;
            byte data[] = new byte[1024];
            InputStream input = new FileInputStream(fileTemp);

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            while ((byteread = input.read(data)) != -1) {
                out.write(data, 0, byteread);
                out.flush();
            }
            content = out.toByteArray();
            input.close();
            out.close();
        } catch(Exception e){
            e.printStackTrace();
        }

        docAttachment.setDocid(0);
        docAttachment.setImagefileid(0);
        docAttachment.setFilerealpath(fileTemp.getPath());
        docAttachment.setIszip(0);
        docAttachment.setFilecontent(Base64.encode(content));
        docAttachment.setFilename(fileTemp.getName());
        return docAttachment;
    }

}

