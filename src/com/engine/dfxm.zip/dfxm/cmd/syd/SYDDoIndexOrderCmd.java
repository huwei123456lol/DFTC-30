package com.engine.dfxm.cmd.syd;

import cn.hutool.core.date.DateUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import com.engine.common.biz.AbstractCommonCommand;
import com.engine.common.entity.BizLogContext;
import com.engine.core.interceptor.CommandContext;
import com.engine.cube.biz.CodeBuilder;
import com.engine.dfxm.manager.PropertiesManager;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import weaver.conn.RecordSet;
import weaver.general.Util;
import weaver.hrm.User;
import weaver.integration.logging.Logger;
import weaver.integration.logging.LoggerFactory;

import java.util.*;

/**
 * ������ȷ��ȡ���ӿ�
 * @author wangkun
 * @date 2023-11-15 19:06
*/
public class SYDDoIndexOrderCmd extends AbstractCommonCommand<Map<String, Object>> {
    private Logger log= LoggerFactory.getLogger();

    public SYDDoIndexOrderCmd(Map<String, Object> params, User user) {
        this.user = user;
        this.params = params;
    }


    @Override
    public BizLogContext getLogContext() {
        return null;
    }

    public static void main(String[] args) {
        System.out.println(DateUtil.format(new Date(),"yyyyMMddHHmmss"));
    }

    @Override
    public Map<String, Object> execute(CommandContext commandContext) {
        Map<String, Object> reMap = new HashMap<String, Object>();
        try {
            String ids = (String) params.get("ids");
            String type = (String) params.get("type");
            String doMsg = (String) params.get("doMsg");
            String sendSap =params.containsKey ("sendSap")?(String) params.get("sendSap"):"";
            String send360 =params.containsKey ("send360")?(String) params.get("send360"):"";
            String msg="";
            boolean status=true;
            boolean statussap=true;
            boolean status360=true;
            //Map<String,Object> checkMap=checkData(ids,type);
            if(!"0".equals(sendSap)){
                //������������SAP
                Map<String, Object> reMapSap=doSendSap("SAPSYDDO",ids,type,doMsg+"(SAP)");
                //if(!(boolean) reMapSap.get("status")){
                msg+=reMapSap.get("msg");
                statussap=(boolean)reMapSap.get("status");
                //}
            }
            if(!"".equals(msg)){
                msg+=";";
            }
            if(!"0".equals(send360)){
                //������������360
                Map<String, Object> reMap360=doSend360("360SYDDO",ids,type,doMsg+"(360)");
                //if(!(boolean) reMap360.get("status")){
                msg+=reMap360.get("msg");
                statussap=(boolean) reMap360.get("status");
                //}
            }
            //"X".equals(type)&&status360&&statussap
            //"X".equals(type)&&status360&&statussap
            if("X".equals(type)&&status360&&statussap){
                RecordSet rs=new RecordSet();
                rs.executeUpdate("update uf_sydlb set zt=0 where id in ("+ids+")");
            }else if("X".equals(type)&&status360&&statussap){
                RecordSet rs=new RecordSet();
                rs.executeUpdate("update uf_sydlb set zt=1 where id in ("+ids+")");
            }
            reMap.put("status",status);
            reMap.put("msg","".equals(msg)?"������ȷ����ɣ�":msg);
        }catch (Exception e){
            reMap.put("status",false);
            reMap.put("msg","������ȷ���쳣��"+e);
        }
        return reMap;
    }

    private Map<String, Object> checkData(String ids, String type,String doMsg) {
        RecordSet rs=new RecordSet();
        Map<String,Object> checkMap=new HashMap<>();
        boolean status=true;
        String msg="";
        if("X".equals(type)){
            String sql="select  ZFLAG_QR360,ZFLAG_QR  from uf_sydlb where id in ("+ids+")";
            rs.executeQuery(sql);
            String ZFLAG_QR="";
            String ZFLAG_QR360="";
            while(rs.next()){
                ZFLAG_QR=rs.getString("ZFLAG_QR");
                ZFLAG_QR360=rs.getString("ZFLAG_QR360");
                if("X".equals(ZFLAG_QR)){
                    msg+= rs.getString("ZSYH")+"��ȷ��,";
                }
                status=false;
                msg+= rs.getString("ZSYH")+",";
            }
            if(!status){
                checkMap.put("status",status);
                checkMap.put("msg",doMsg+"("+msg.substring(0,msg.length()-1)+")�޷�ȷ�ϣ�ֻ��δȷ�Ϲ���������������ȷ�ϣ�������ѡ��");
                return checkMap;
            }
        }else if("Y".equals(type)){
            String sql="select * from uf_sydlb where id in ("+ids+") and (ZFLAG_QR360<>'X' or EKGRP1='X') ";
            rs.executeQuery(sql);
            while(rs.next()){
                status=false;
                msg+= rs.getString("ZSYH")+",";
            }
            if(!status){
                checkMap.put("status",status);
                checkMap.put("msg",doMsg+"("+msg.substring(0,msg.length()-1)+")�޷�ȡ��ȷ�ϣ�ֻ����ȷ�ϵ�δ������Ŀ�ſ���ȡ����������ѡ��");
                return checkMap;
            }
        }
        return checkMap;
    }

    /**
     * ����ȷ���������ŵ�360
     * @author wangkun
     * @date 2024-10-16 14:49
     * @param operateCode 
     * @param ids 
     * @param type 
     * @param doMsg
     * @return java.util.Map<java.lang.String,java.lang.Object>
     */
    private Map<String, Object> doSend360(String operateCode, String ids,String type,String doMsg) {
        Map<String, Object> reMap = new HashMap<String, Object>();
        try {
            reMap.put("status",true);
            log.info("��ʼ360������ȷ�ϣ�"+operateCode+"==="+ids+"---"+type+"----"+doMsg);
            PropertiesManager pm=new PropertiesManager(operateCode,1);
            JSONObject pmObj=pm.getFieldValueObj();
            String password="";
            String contentType="";
            String apiUrl="";
            if(pmObj.containsKey("urlCode")){
                String urlCode=pmObj.getString("urlCode");
                PropertiesManager apipm=new PropertiesManager(urlCode,1);
                JSONObject apipmObj=apipm.getFieldValueObj();
                password=apipmObj.getString("token");
                contentType=apipmObj.getString("contentType");
                apiUrl=apipmObj.getString("url")+pmObj.getString("api");
            }else{
                password=pmObj.getString("token");
                contentType=pmObj.getString("contentType");
                apiUrl=pmObj.getString("url");
            }
            RecordSet rs=new RecordSet();
            int modeid = pmObj.getInt("modeid");
            int formid = pmObj.getInt("formid");
            String codefieldid = pmObj.getString("codefieldid");
            log.info(doMsg+"������Ϣ"+pmObj);
            String sql="select ZQRSYH,ZFLAG_QR360,EKGRP1,id,SAP_SUPPLIER_CODE,SAP_VOUCHER_CODE,SAP_VOUCHER_PROJECT_CODE from uf_sydlb where id in ("+ids+")";
            log.info("������360ȷ�����ݲ�ѯ"+sql);
            rs.executeQuery(sql);
            JSONArray dataArr360=new JSONArray();

            while (rs.next()){
                String ZFLAG_QR360=rs.getString("ZFLAG_QR360");
                String EKGRP1=rs.getString("EKGRP1");
                if("X".equals(ZFLAG_QR360)&&"X".equals(type)){
                    //��ǰ����Ϊȷ�ϡ�X�����ҵ�ǰȷ�ϱ�ʶΪ��ȷ�ϡ�X��������������
                    continue;
                }else if(("Y".equals(type)&&"X".equals(ZFLAG_QR360)&&"X".equals(EKGRP1))||("Y".equals(type)&&!"X".equals(ZFLAG_QR360))){
                    //��ǰ����Ϊȡ��ȷ�ϡ�Y�����ҵ�ǰȷ�ϱ�ʶΪ��ȷ�ϡ�X�����ҷ�Ʊ�����ʶΪ��ȷ�ϡ�X�� ��������ȡ��ȷ�ϣ���������
                    //���ߵ�ǰ����Ϊȡ��ȷ�ϡ�Y�����ҵ�ǰȷ�ϱ�ʶΪδȷ�ϣ�������ȡ��ȷ�ϣ���������
                    continue;
                }
                String ZQRSYH=Util.null2String(rs.getString("ZQRSYH"));
                //if("".equals(ZQRSYH)){
                //    CodeBuilder cbuild = new CodeBuilder(modeid);
                //    Map<String,Object>  codeMap=cbuild.getModeCodeStr(formid,rs.getInt("id"));//���ɱ��
                //    ZQRSYH=Util.null2String(codeMap.get(codefieldid));
                //}
                setArr(dataArr360,rs.getString("id"),ZQRSYH,type);
            }
            if(dataArr360.size()>0){
                log.info(doMsg+"���ͱ���: "+"  params:"+dataArr360);
                HttpRequest request=HttpUtil.createPost(apiUrl);
                request.header("Authorization",password);
                request.header("Content-Type",contentType);
                request.body(dataArr360.toString());
                HttpResponse response=request.execute();
                String errmsg=doMsg;
                if(response.isOk()){
                    String ret=response.body();
                    log.info(doMsg+"���ر��ģ�"+ret);
                    //[{"MESSAGE":"�ɹ�","CONFIRM_INDEX_CODE":"TC1224202300002","CONFIRM_FLAG":"X",
                    //        "MESSAGE_TYPE":"S","SAP_SUPPLIER_CODE":"1008773","SAP_VOUCHER_PROJECT_CODE":"1","SAP_VOUCHER_CODE":"5012723078"}]
                    JSONArray retJson=JSONArray.fromObject(ret);
                    sql="update uf_sydlb set ZFLAG_QR360=?,ZMSG360=? where ZQRSYH=?";
                    String backsql="update uf_sydlb set ZMSG360=? where ZQRSYH=?";
                    List<List> upList=new ArrayList<>();
                    List<List> backupList=new ArrayList<>();
                    for (int i = 0; i < retJson.size(); i++) {
                        JSONObject row=retJson.getJSONObject(i);
                        List upRow=new ArrayList();
                        log.info("��ʼ����������"+row);
                        String ZQRSYH=row.getString("CONFIRM_INDEX_CODE");
                        if("S".equals(row.getString("MESSAGE_TYPE"))){
                            errmsg+="("+ZQRSYH+")"+row.getString("MESSAGE");
                            upRow.add(type);
                            upRow.add(row.getString("MESSAGE"));
                            upRow.add(ZQRSYH);
                            upList.add(upRow);
                        }else{
                            reMap.put("status",false);
                            errmsg+="("+ZQRSYH+")"+row.getString("MESSAGE");
                            upRow.add(row.getString("MESSAGE"));
                            upRow.add(ZQRSYH);
                            backupList.add(upRow);
                        }
                    }
                    log.info("��ʼ��������");
                    if(upList.size()>0){
                        log.info(doMsg+"�����ɹ���");
                        rs.executeBatchSql(sql,upList);
                    }
                    if(backupList.size()>0){
                        log.info(doMsg+"����ʧ�ܣ�");
                        rs.executeBatchSql(backsql,backupList);
                    }
                    reMap.put("msg",errmsg);
                    log.info(errmsg);
                }else{
                    log.error(doMsg+"ʧ��,"+response.body());
                    reMap.put("status",false);
                    reMap.put("msg",doMsg+"ʧ��,"+response.body());
                    sql="update uf_sydlb set ZMSG360='"+"ȡ��ʧ��,"+response.body()+"' where id in ("+ids+")";
                    log.info(doMsg+"==="+sql);
                    rs.executeUpdate(sql);
                }
            }else{
                log.info(doMsg+"û����Ҫ����������type:"+type);
                reMap.put("status",false);
                reMap.put("msg",doMsg+"û����Ҫ����������type:"+type);
            }
        }catch (Exception e){
            log.error(doMsg+"==�쳣"+e);
            reMap.put("status",false);
            reMap.put("msg",doMsg+"ʧ��,�������ӿ��쳣��"+e);
            String sql="update uf_sydlb set ZMSG360='"+doMsg+"ʧ��,�������ӿ��쳣��"+e.getMessage()+"' where id in ("+ids+")";
            RecordSet rs=new RecordSet();
            rs.executeUpdate(sql);
        }
        return reMap;
    }

    private void setArr(JSONArray dataArr360, String id, String ZQRSYH, String type) {
        String sql="select * from uf_sydlb_dt1 where mainid="+id;
        RecordSet rs=new RecordSet();
        rs.executeQuery(sql);
        while (rs.next()){
            JSONObject row360=new JSONObject();
            row360.put("CONFIRM_INDEX_CODE", ZQRSYH);//ȷ����������
            row360.put("SAP_SUPPLIER_CODE",Util.null2String(rs.getString("SAP_SUPPLIER_CODE")));//SAP��Ӧ�̱���
            row360.put("SAP_VOUCHER_CODE",Util.null2String(rs.getString("SAP_VOUCHER_CODE")));//SAP����ƾ֤��
            row360.put("SAP_VOUCHER_PROJECT_CODE",Util.null2String(rs.getString("SAP_VOUCHER_PROJECT_CODE")));//SAP����ƾ֤��Ŀ��
            row360.put("CONFIRM_FLAG",type);//ȷ�ϱ�ʶ
            dataArr360.add(row360);
        }
    }

    private void setSAPArr(JSONArray dataArr, String id, String ZQRSYH, String type) {
        String sql="select * from uf_sydlb_dt1 where mainid="+id;
        RecordSet rs=new RecordSet();
        rs.executeQuery(sql);
        while (rs.next()){
            JSONObject row=new JSONObject();
            row.put("ZQRSYH", ZQRSYH);//ȷ����������
            row.put("LIFNR",Util.null2String(rs.getString("SAP_SUPPLIER_CODE")));//SAP��Ӧ�̱���
            row.put("BELNR",Util.null2String(rs.getString("SAP_VOUCHER_CODE")));//SAP����ƾ֤��
            row.put("BUZEI",Util.null2String(rs.getString("SAP_VOUCHER_PROJECT_CODE")));//SAP����ƾ֤��Ŀ��
            row.put("ZFLAG_QR",type);//ȷ�ϱ�ʶ
            dataArr.add(row);
        }
    }

    /**
     * ����ȷ���������ŵ�SAP
     * @author wangkun
     * @date 2024-10-16 14:49
     * @param operateCode
     * @param ids
     * @param type
     * @param doMsg
     * @return java.util.Map<java.lang.String,java.lang.Object>
     */
    public Map<String, Object> doSendSap(String operateCode,String ids,String type,String doMsg) {
        Map<String, Object> reMap = new HashMap<String, Object>();
        try {
            PropertiesManager pm=new PropertiesManager(operateCode,1);
            JSONObject pmObj=pm.getFieldValueObj();
            String loginid=pmObj.getString("loginid");
            String password=pmObj.getString("token");
            String Xappid=pmObj.getString("Xappid");
            String sapClient=pmObj.getString("sapClient");
            String contentType=pmObj.getString("contentType");
            int modeid = pmObj.getInt("modeid");
            int formid = pmObj.getInt("formid");
            String codefieldid = pmObj.getString("codefieldid");
            log.info(doMsg+"������Ϣ"+pmObj);
            reMap.put("status",false);
            RecordSet rs=new RecordSet();
            //String sql="select *  from uf_sydlb where id in ("+ids+")";
            String sql="select ZQRSYH,ZFLAG_QR,EKGRP1,id,SAP_SUPPLIER_CODE,SAP_VOUCHER_CODE,SAP_VOUCHER_PROJECT_CODE from uf_sydlb where id in ("+ids+")";
            log.info("������SAPȷ�����ݲ�ѯ"+sql);
            rs.executeQuery(sql);
            JSONObject paramObj=new JSONObject();
            JSONArray dataArr=new JSONArray();
            while (rs.next()){
                String ZFLAG_QR=rs.getString("ZFLAG_QR");
                String EKGRP1=rs.getString("EKGRP1");
                if("X".equals(ZFLAG_QR)&&"X".equals(type)){
                    //��ǰ����Ϊȷ�ϡ�X�����ҵ�ǰȷ�ϱ�ʶΪ��ȷ�ϡ�X��������������
                    continue;
                }else if(("Y".equals(type)&&"X".equals(ZFLAG_QR)&&"X".equals(EKGRP1))||("Y".equals(type)&&!"X".equals(ZFLAG_QR))){
                    //��ǰ����Ϊȡ��ȷ�ϡ�Y�����ҵ�ǰȷ�ϱ�ʶΪ��ȷ�ϡ�X�����ҷ�Ʊ�����ʶΪ��ȷ�ϡ�X�� ��������ȡ��ȷ�ϣ���������
                    continue;
                }
                //ÿ��ȷ������������������
                String ZQRSYH=Util.null2String(rs.getString("ZQRSYH"));
                if("X".equals(type)){
                    //    �����ȷ�ϣ�������������������
                    //20240826����Ϊÿ��ȷ���������ɱ��
                    CodeBuilder cbuild = new CodeBuilder(modeid);
                    Map<String,Object>  codeMap=cbuild.getModeCodeStr(formid,rs.getInt("id"));//���ɱ��
                    ZQRSYH=Util.null2String(codeMap.get(codefieldid));
                }
                setSAPArr(dataArr,rs.getString("id"),ZQRSYH,type);
            }

            if(dataArr.size()>0){
                paramObj.put("INFID","COS001");
                paramObj.put("ZSCOS001_REQ",dataArr);
                log.info(doMsg+"���ͱ��� params:"+paramObj);
                HttpRequest request=HttpUtil.createPost(pmObj.getString("url"));
                request.basicAuth(loginid,password);
                Map header=new HashMap();
                String timeStamp=DateUtil.format(new Date(),"yyyyMMddHHmmss");
                header.put("X-App-Id",Xappid);
                header.put("X-Sequence-No", timeStamp);
                header.put("X-Timestamp",timeStamp);
                header.put("sap-client",sapClient);
                header.put("Content-Type",contentType);
                request.addHeaders(header);
                request.body(paramObj.toString());
                log.info(doMsg+"���ͱ��ģ�header:"+JSONObject.fromObject(header));
                HttpResponse response=request.execute();
                String errmsg=doMsg;
                if(response.getStatus()==200){
                    String ret=response.body();
                    log.info(doMsg+"���ر��ģ�"+ret);
                    //{"ZSCOS001_RES":[{"ZQRSYH":"TC1224202300008","LIFNR":"1008773","BELNR":"5012723078","BUZEI":"0002","ZFLAG_QR":"X","ZRET":"S","ZMSG":"���³ɹ�"}]
                    // ,"RETCODE":"S","RETMSG":"���ݽ��ճɹ�"}
                    JSONObject retJson=JSONObject.fromObject(ret);
                    if(retJson.containsKey("RETCODE")&&"S".equals(retJson.getString("RETCODE"))){
                        sql="update uf_sydlb set ZFLAG_QR=?,ZMSG=? where ZQRSYH=?";
                        String backsql="update uf_sydlb set ZMSG=? where ZQRSYH=?";
                        List<List> upList=new ArrayList<>();
                        List<List> backupList=new ArrayList<>();
                        log.info("��ʼ������������");
                        if(retJson.containsKey("ZSCOS001_RES")){
                            JSONArray ZSCOS001_RES=retJson.getJSONArray("ZSCOS001_RES");
                            for (int i = 0; i < ZSCOS001_RES.size(); i++) {
                                JSONObject row=ZSCOS001_RES.getJSONObject(i);
                                log.info("������������"+ZSCOS001_RES+row);
                                String ZQRSYH=row.containsKey("ZQRSYH")?row.getString("ZQRSYH"):"";
                                List upRow=new ArrayList();
                                if("S".equals(row.getString("ZRET"))){
                                    //�����ɹ�����ʶ����
                                    errmsg+="("+ZQRSYH+")"+row.getString("ZMSG");
                                    upRow.add(type);
                                    upRow.add(row.getString("ZMSG"));
                                    upRow.add(ZQRSYH);
                                    upList.add(upRow);
                                }else{
                                    //����ʧ�ܣ���ʶά��ԭ��,�������ȡ��ȷ�ϣ���ԭ��ʶΪX�������ȷ�ϣ���ԭ��ʶΪ��
                                    errmsg+="("+ZQRSYH+")"+row.getString("ZMSG");
                                    reMap.put("status",false);
                                    upRow.add(row.getString("ZMSG"));
                                    upRow.add(ZQRSYH);
                                    backupList.add(upRow);
                                }
                            }
                            if(upList.size()>0){
                                log.info("ִ�и���");
                                rs.executeBatchSql(sql,upList);
                            }
                            if(backupList.size()>0){
                                log.info("ִ�и�����ʷ");
                                rs.executeBatchSql(backsql,backupList);
                            }
                            reMap.put("msg",errmsg);
                            log.info(doMsg+"��ɣ�");
                        }else{
                            log.info(doMsg+"���������ͣ���δ���سɹ����,ȷ��ʧ�ܣ�");
                            reMap.put("status",false);
                            reMap.put("msg",doMsg+"���������ͣ���δ���سɹ����,ȷ��ʧ�ܣ�");
                            sql="update uf_sydlb set ZMSG='"+doMsg+"���������ͣ���δ���سɹ����,ȷ��ʧ�ܣ�"+"' where id in ("+ids+")";
                            rs.executeUpdate(sql);
                        }
                    }else{
                        log.info(doMsg+"ʧ��,"+retJson.getString("RETMSG"));
                        reMap.put("status",false);
                        reMap.put("msg",doMsg+"ʧ��,"+retJson.getString("RETMSG"));
                        sql="update uf_sydlb set ZMSG='"+retJson.getString("RETMSG")+"' where id in ("+ids+")";
                        rs.executeUpdate(sql);
                    }
                }else{
                    log.info(doMsg+"ʧ��,"+response.body());
                    reMap.put("status",false);
                    reMap.put("msg",doMsg+"ʧ��,"+response.body());
                    sql="update uf_sydlb set ZMSG='"+"ȡ��ʧ��,"+response.body()+"' where id in ("+ids+")";
                    rs.executeUpdate(sql);
                }
            }else{
                log.info(doMsg+"û����Ҫ����������type:"+type);
                reMap.put("status",false);
                reMap.put("msg",doMsg+"û����Ҫ����������type:"+type);
            }
        }catch (Exception e){
            log.info(doMsg+"ʧ��,�������ӿ��쳣��"+e);
            reMap.put("status",false);
            reMap.put("msg",doMsg+"ʧ��,�������ӿ��쳣��"+e);
            String sql="update uf_sydlb set ZMSG='"+doMsg+"ʧ��,�������ӿ��쳣��"+e.getMessage()+"' where id in ("+ids+")";
            RecordSet rs=new RecordSet();
            rs.executeUpdate(sql);
        }
        return reMap;
    }
}
